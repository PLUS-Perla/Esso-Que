import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EventosComponent } from './components/eventos/eventos.component';
import { PreciosComponent } from './components/precios/precios.component';
import { CancionesComponent } from './components/canciones/canciones.component';
import { ProductosComponent } from './components/productos/productos.component';

const routes: Routes = [
  {path:'eventos', component:EventosComponent},
  {path:'precios', component:PreciosComponent},
  {path:'canciones', component:CancionesComponent},
  {path:'productos', component:ProductosComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents=[EventosComponent, PreciosComponent, CancionesComponent, ProductosComponent]
